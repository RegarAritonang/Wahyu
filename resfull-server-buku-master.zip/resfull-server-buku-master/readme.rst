###################
1818045 Muhammad Rizky Al irbad
###################
Public rest server sederhana

*******************
Documentation
*******************
- get data = http://localhost/resfull-server-buku/book
- get data by id = http://localhost/resfull-server-buku/book?id=masukan_No_id
- get data by tahun terbit = http://localhost/resfull-server-buku/book?tahun=masukan_tahun

*******************
Input
*******************
input = http://localhost/resfull-server-buku/book
parameter = judul_buku, pengarang, tahun_terbit

*******************
delete
*******************
input = http://localhost/resfull-server-buku/book
parameter = id

*******************
update
*******************
input = http://localhost/resfull-server-buku/book
parameter = judul_buku, pengarang, tahun_terbit
